
from importlib.resources import files
from nemoguardrails import LLMRails, RailsConfig

def get_config_path():
    return str(files("company_nemo_guardrails").joinpath("config"))

def create_rails():
    config = RailsConfig.from_path(get_config_path())
    return LLMRails(config)
